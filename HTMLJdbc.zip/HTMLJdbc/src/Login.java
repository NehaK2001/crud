import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class Login extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String e=req.getParameter("email");
		String p=req.getParameter("pass");
		 System.out.println(e+" "+p);
		
		 try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded");
			
			
		    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root" ,"root");
			System.out.println("Connection Success");
			
		PreparedStatement pstm=	con.prepareStatement("select * from webuser where email=?");
		pstm.setString(1, e);
		
		
		String email=null;
		String pass=null;
		String name=null;
		
		ResultSet rs=pstm.executeQuery();
		
		while(rs.next()) {
		name=rs.getString("name");
	    email=rs.getString("email");
		pass=rs.getString("password");
		}
	 
		//PrintWriter pw=resp.getWriter();
		
		if(e.equals(email)&&p.equals(pass)) {
			System.out.println("welcome user: "+name);
			//pw.write("welcome user"+name);
			
			resp.sendRedirect("UpdateUser.html");
		}else
		
		{
			System.out.println("login invalid");
			//pw.write("login Invalid");
			resp.sendRedirect("LoginUser.html");
		}
			con.close();
		} catch (ClassNotFoundException el) {
			el.printStackTrace();
		} catch (SQLException el) {
			el.printStackTrace();
		}
		 
	}
}
