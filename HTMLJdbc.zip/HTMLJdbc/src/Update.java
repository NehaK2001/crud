import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateServlet")
public class Update extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String nm=req.getParameter("name");
	String e=req.getParameter("email");
		System.out.println(nm+" "+e);
		
		
		 try {
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("Driver Loaded");
				
				
			    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root" ,"root");
				System.out.println("Connection Success");
				
				PreparedStatement pstm=	con.prepareStatement("update webuser set name=? where email=?");
				pstm.setString(1, nm);
				pstm.setString(2, e);
				
				 int i =pstm.executeUpdate();
				// PrintWriter pw=resp.getWriter();
				 
						if(i!=0) {
						System.out.println("Record updated ");
						//pw.write("Record updated");
						
						resp.sendRedirect("DeleteUser.html");
					}else {
						System.out.println("Error");
						//pw.write("error");
						
						resp.sendRedirect("UpdateUser.html");
						
						  }
						con.close();
					} catch (ClassNotFoundException el) {
						el.printStackTrace();
					} catch (SQLException el) {
						el.printStackTrace();
					}	 
				}		
			}
		
	

